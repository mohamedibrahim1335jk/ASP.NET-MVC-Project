﻿namespace AbpCompanyName.AbpProjectName.Authorization.Accounts.Dto
{
    public class RegisterOutput
    {
        public bool CanLogin { get; set; }
    }
}
