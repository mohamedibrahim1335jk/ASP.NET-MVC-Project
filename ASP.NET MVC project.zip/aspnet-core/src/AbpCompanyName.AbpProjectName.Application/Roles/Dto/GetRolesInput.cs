﻿namespace AbpCompanyName.AbpProjectName.Roles.Dto
{
    public class GetRolesInput
    {
        public string Permission { get; set; }
    }
}
